/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        cardboard: {
          brown: '#a07855',
          light: '#d7b594',
          dark: '#6e473b'
        },
        peach: {
          matte: '#f5cdc2',
          light: '#fff0eb'
        },
        charcoal: {
          twilight: '#1e1e24'
        },
        slate: {
          matte: '#34343d'
        }
      }
    },
  },
  plugins: [],
}