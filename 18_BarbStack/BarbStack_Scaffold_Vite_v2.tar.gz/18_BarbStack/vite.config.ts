import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Configuration for Barb's Stack (Port 3020)
export default defineConfig({
  plugins: [react()],
  server: {
    port: 3020,
    host: '0.0.0.0',
    fs: {
      allow: ['..']
    }
  }
});